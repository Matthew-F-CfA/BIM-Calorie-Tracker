package bim.calorieTracker;

import java.awt.*;
import java.awt.event.*;

class ListDialog2 extends Dialog
implements ActionListener {
  List lstList;
  Button btnSelect=new Button("Select All");
  Button btnCancel=new Button("Cancel");
  volatile boolean cancelIt=false;

  ListDialog2(Frame parent, String strTitle, List lstList) {
    super(parent, strTitle, true);
    this.lstList=lstList;

    lstList.setMultipleMode(true);

    add("Center", lstList);

    Panel tempPan=new Panel();
    tempPan.add(btnSelect);
    btnSelect.addActionListener(this);
    tempPan.add(btnCancel);
    btnCancel.addActionListener(this);
    add("South", tempPan);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
   Object evSource=ae.getSource();

    if(evSource==btnSelect) {
      int intSelectedIndices[]=lstList.getSelectedIndexes();
      if(intSelectedIndices.length==0)
        return;

      cancelIt=false;
      dispose();
    }
    else if(evSource==btnCancel) {
      cancelIt=true;
      dispose();
    }
  }
}