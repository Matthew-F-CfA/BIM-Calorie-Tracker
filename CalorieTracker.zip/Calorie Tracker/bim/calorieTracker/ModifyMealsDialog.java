package bim.calorieTracker;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Date;
import java.util.Arrays;
import java.util.Comparator;

class ModifyMealsDialog extends Dialog
implements ActionListener {
  Date dateDate;
  Vector vecMeals;

  List lstMeals=new List(5);
  Button btnDelete=new Button("Delete Meal");

  TextField txtMealName=new TextField();
  TextField txtMealCalories=new TextField();
  TextField txtMealHour=new TextField();
  TextField txtMealMinute=new TextField();
  Button btnAdd=new Button("Add Meal");

  Button btnDone=new Button("Done");


  ModifyMealsDialog(Frame parent, Date dateDate, Vector vecMeals) {
    super(parent, "Modify Meals Dialog: "+dateDate.toString(), true);
    this.dateDate=dateDate;
    this.vecMeals=vecMeals;

    for(int i=0;i<vecMeals.size();i++) {
      MealObject nextMeal=(MealObject)vecMeals.elementAt(i);

      lstMeals.add(nextMeal.getName()+":"+nextMeal.getCalories()+":"+nextMeal.getDate().toString());
    }

/*
    MealObject meals[]=new MealObject[vecMeals.size()];
    for(int i=0;i<vecMeals.size();i++)
      meals[i]=(MealObject)vecMeals.elementAt(i);

    Arrays.sort(meals, new MealComparator());

    for(int i=0;i<meals.length;i++)
      lstMeals.add(meals[i].getName()+":"+meals[i].getCalories()+":"+meals[i].getDate().toString());
*/

    add("North", new Label("Meals:"));
    add("Center", lstMeals);

    Panel tempPan=new Panel();
    tempPan.setLayout(new GridLayout(8, 1));
    tempPan.add(btnDelete);
    btnDelete.addActionListener(this);
    tempPan.add(new Label("Add Meal:"));
    Panel tempPanA=new Panel();
    tempPanA.setLayout(new GridLayout(1, 2));
    tempPanA.add(new Label("Meal Name:"));
    tempPanA.add(txtMealName);
    tempPan.add(tempPanA);
    Panel tempPanB=new Panel();
    tempPanB.setLayout(new GridLayout(1, 2));
    tempPanB.add(new Label("Meal Calories:"));
    tempPanB.add(txtMealCalories);
    tempPan.add(tempPanB);
    Panel tempPanC=new Panel();
    tempPanC.setLayout(new GridLayout(1, 2));
    tempPanC.add(new Label("Hour Eaten:"));
    tempPanC.add(txtMealHour);
    tempPan.add(tempPanC);
    Panel tempPanD=new Panel();
    tempPanD.setLayout(new GridLayout(1, 2));
    tempPanD.add(new Label("Minute Eaten:"));
    tempPanD.add(txtMealMinute);
    tempPan.add(tempPanD);
    tempPan.add(btnAdd);
    btnAdd.addActionListener(this);
    Panel tempPanE=new Panel();
    tempPanE.add(btnDone);
    btnDone.addActionListener(this);
    tempPan.add(tempPanE);
    add("South", tempPan);

    Dimension screenDim=Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenDim.width/4, screenDim.height/4);
    setSize(screenDim.width/2, screenDim.height/2);
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==btnDelete) {
      int intSelIndex=lstMeals.getSelectedIndex();
      if(intSelIndex==-1)
        return;

      lstMeals.remove(intSelIndex);

      vecMeals.removeElementAt(intSelIndex);
    }
    else if(evSource==btnAdd) {
      String strName=txtMealName.getText();

      if(strName.length()==0) {
        txtMealName.setText("Error. Name required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtMealName.setText("");

        return;
      }


      String strCalories=txtMealCalories.getText();

      if(strCalories.length()==0) {
        txtMealCalories.setText("Error. Calories required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtMealCalories.setText("");

        return;
      }

      int intCalories=-1;
      try {
        intCalories=Integer.parseInt(strCalories);
      }
      catch(Exception ex) {
        txtMealCalories.setText("Error. Calories must be an integer.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex2) {
        }
        txtMealCalories.setText(strCalories);

        return;
      }


      String strHour=txtMealHour.getText();

      if(strHour.length()==0) {
        txtMealHour.setText("Error. Hour required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtMealHour.setText("");

        return;
      }

      int intHour=-1;
      try {
        intHour=Integer.parseInt(strHour);
      }
      catch(Exception ex) {
        txtMealHour.setText("Error. Hour must be an integer.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex2) {
        }
        txtMealHour.setText(strHour);

        return;
      }

      if(intHour<0 || intHour>23) {
        txtMealHour.setText("Error. Hour must be between 0-23.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtMealHour.setText("");

        return;
      }


      String strMinute=txtMealMinute.getText();

      if(strMinute.length()==0) {
        txtMealMinute.setText("Error. Minute required.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtMealMinute.setText("");

        return;
      }

      int intMinute=-1;
      try {
        intMinute=Integer.parseInt(strMinute);
      }
      catch(Exception ex) {
        txtMealMinute.setText("Error. Minute must be an integer.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex2) {
        }
        txtMealMinute.setText(strMinute);

        return;
      }

      if(intMinute<0 || intMinute>59) {
        txtMealMinute.setText("Error. Minute must be between 0-59.");
        try {
          Thread.sleep(3000);
        }
        catch(Exception ex) {
        }
        txtMealMinute.setText("");

        return;
      }


      Date dateObj=new Date(dateDate.getYear(), dateDate.getMonth(), dateDate.getDate(), intHour, intMinute);

      MealObject mealObj=new MealObject(strName, intCalories, dateObj);

      MealObject meals[]=new MealObject[vecMeals.size()+1];
      for(int i=0;i<vecMeals.size();i++)
        meals[i]=(MealObject)vecMeals.elementAt(i);

      meals[meals.length-1]=mealObj;

      Arrays.sort(meals, new MealComparator());

      lstMeals.removeAll();
      for(int i=0;i<meals.length;i++)
        lstMeals.add(meals[i].getName()+":"+meals[i].getCalories()+":"+meals[i].getDate().toString());

      vecMeals.removeAllElements();
      for(int i=0;i<meals.length;i++)
        vecMeals.addElement(meals[i]);
    }
    else if(evSource==btnDone) {
      dispose();
    }
  }

  class MealComparator
  implements Comparator {

    MealComparator() {
    }

    public int compare(Object obj, Object obj2) {
      MealObject mObj=(MealObject)obj;
      MealObject mObj2=(MealObject)obj2;

      return mObj.dateDate.compareTo(mObj2.dateDate);
    }

    public boolean equals(Object obj) {
      return false;
    }
  }
}