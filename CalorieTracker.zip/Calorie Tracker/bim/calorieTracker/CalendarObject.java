package bim.calorieTracker;

import java.io.Serializable;
import java.util.Hashtable;

class CalendarObject
implements Serializable {
  Hashtable hashMeals=new Hashtable(); //Keys are Date and Values are Vector containing elements of MealObject

  CalendarObject() {
  }

  public Hashtable getMeals() {
    return hashMeals;
  }

  public void setMeals(Hashtable hashMeals) {
    this.hashMeals=hashMeals;
  }
}