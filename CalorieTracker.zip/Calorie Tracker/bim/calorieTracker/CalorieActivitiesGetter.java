package bim.calorieTracker;

import java.util.Hashtable;
import java.io.*;

class CalorieActivitiesGetter {

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  java bim.calorieTracker.CalorieActivitiesGetter <activity name> <weight in increments of 10 from 80-500>");

        return;
      }

      ObjectInputStream ois=new ObjectInputStream(new FileInputStream(new File("CalorieActivities")));
      Hashtable hashActivities=(Hashtable)ois.readObject();
      ois.close();

      String strName=args[0];
      String strWeight=args[1];

      Hashtable hashActivitiesSub=(Hashtable)hashActivities.get(strName);
      String strCalories=(String)hashActivitiesSub.get(strWeight);

      System.out.println(strCalories);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}