package bim.calorieTracker;

import java.util.Hashtable;
import java.io.*;

class CalorieActivitiesMaker {

  public static void main(String args[]) {
    try {
      if(args.length==0) {
        System.out.println("Usage:");
        System.out.println("  java bim.calorieTracker.CalorieActivitiesMaker <folder containing files to parse>");

        return;
      }

      File fileDir=new File(args[0]);
      if(!fileDir.exists()) {
        System.out.println("Folder doesn't exist.");

        return;
      }

      Hashtable hashActivities=new Hashtable();

      File fileList[]=fileDir.listFiles();
      for(int i=0;i<fileList.length;i++) {
        if(fileList[i].isDirectory())
          continue;

        String strWeight=fileList[i].getName();
        strWeight=strWeight.substring(0, strWeight.indexOf("."));

        StringBuffer sBuf=new StringBuffer();

        BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(fileList[i])));

        String strNextLine="";
        while((strNextLine=br.readLine())!=null) {
          sBuf.append(strNextLine);
          sBuf.append("\n");
        }

        br.close();

        String strFile=sBuf.toString();

        int intTableIndex=strFile.indexOf("<TABLE ");

        intTableIndex=strFile.indexOf("<TABLE ", intTableIndex+1);
        intTableIndex=strFile.indexOf("<TABLE ", intTableIndex+1);

        int intRowIndex=strFile.indexOf("<TR", intTableIndex);

        intRowIndex+=1;

        int intTDIndex=-1;

        int intFontIndex=-1;
        int intFontIndex2=-1;

        while(true) {
          intRowIndex=strFile.indexOf("<TR", intRowIndex);

          if(intRowIndex==-1)
            break;

          intTDIndex=strFile.indexOf("<TD", intRowIndex);

          intFontIndex=strFile.indexOf("<FONT", intTDIndex);

          intFontIndex=strFile.indexOf(">", intFontIndex);

          intFontIndex2=strFile.indexOf("</FONT>", intFontIndex);

          String strNextActivityName=strFile.substring(intFontIndex+1, intFontIndex2);

          intTDIndex=strFile.indexOf("<TD", intFontIndex2);

          intFontIndex=strFile.indexOf("<FONT", intTDIndex);

          intFontIndex=strFile.indexOf(">", intFontIndex);

          intFontIndex2=strFile.indexOf("</FONT>", intFontIndex);

          String strNextActivityCategory=strFile.substring(intFontIndex+1, intFontIndex2);
          
          intTDIndex=strFile.indexOf("<TD", intFontIndex2);

          intFontIndex=strFile.indexOf("<FONT", intTDIndex);

          intFontIndex=strFile.indexOf(">", intFontIndex);

          intFontIndex2=strFile.indexOf("</FONT>", intFontIndex);

          String strNextActivityCalories=strFile.substring(intFontIndex+1, intFontIndex2);

          strNextActivityName=strNextActivityName.replace("\n", "");
          strNextActivityCategory=strNextActivityCategory.replace("\n", "");
          strNextActivityCalories=strNextActivityCalories.replace("\n", "");

          strNextActivityName=strNextActivityCategory+": "+strNextActivityName;

          int intSpaceIndex=strNextActivityName.indexOf(" ");
          if(intSpaceIndex!=-1) {
            do {
              int intExtraSpaceCount=0;

              ++intSpaceIndex;

              while(true) {
                if(strNextActivityName.charAt(intSpaceIndex)==' ') {
                  ++intExtraSpaceCount;
                  ++intSpaceIndex;
                  continue;
                }

                break;
              }

              if(intExtraSpaceCount>0)
                strNextActivityName=strNextActivityName.substring(0, intSpaceIndex-intExtraSpaceCount)+strNextActivityName.substring(intSpaceIndex);

              intSpaceIndex=strNextActivityName.indexOf(" ", intSpaceIndex-intExtraSpaceCount);

              if(intSpaceIndex==-1)
                break;

            } while(true);
          }

/*
          while(true) {
            String strNextActivityName0=strNextActivityName.replace("  ", " ");
            if(strNextActivityName.equals(strNextActivityName0))
              break;
          }
*/

          strNextActivityName=strNextActivityName.replace("&lt;", "<");
          strNextActivityName=strNextActivityName.replace("&gt;", ">");

          Hashtable hashActivitiesSub=(Hashtable)hashActivities.get(strNextActivityName);

          if(hashActivitiesSub==null) {
            hashActivitiesSub=new Hashtable();
            hashActivities.put(strNextActivityName, hashActivitiesSub);
          }

          hashActivitiesSub.put(strWeight, strNextActivityCalories);

          intRowIndex=intFontIndex2;
        }
      }

      ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("CalorieActivities")));
      oos.writeObject(hashActivities);
      oos.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
}