package bim.calorieTracker;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Date;
import java.util.Vector;
import java.util.Hashtable;
import java.util.TreeMap;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Arrays;
import java.util.Map;
import java.util.Iterator;
import java.io.*;

class ViewAverageCaloriesChooserStartFrame extends Frame
implements ActionListener {
  ViewAverageCaloriesChooserStartFrame refThis;

  CalorieTrackerExecutor calExecutor;

  CalendarCanvas calCanvas=new CalendarCanvas();

  Menu menuOptions=new Menu("Options");
  Menu menuOptionsCalendar=new Menu("Calendar");
  MenuItem menuOptionsCalendarSetYear=new MenuItem("Set Year");
  MenuItem menuOptionsCalendarSetMonth=new MenuItem("Set Month");


  ViewAverageCaloriesChooserStartFrame(CalorieTrackerExecutor calExecutor) {
    super("View Average Calories Start Date");
    refThis=this;
    this.calExecutor=calExecutor;

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        refThis.setVisible(false);

        calExecutor.setVisible(true);
      }
    });

    add("Center", calCanvas);

    menuOptions.add(menuOptionsCalendar);
    menuOptionsCalendar.add(menuOptionsCalendarSetYear);
    menuOptionsCalendarSetYear.addActionListener(this);
    menuOptionsCalendar.add(menuOptionsCalendarSetMonth);
    menuOptionsCalendarSetMonth.addActionListener(this);

    MenuBar mBar=new MenuBar();
    mBar.add(menuOptions);

    setMenuBar(mBar);
  }

  public void setCalorieTrackerExecutor(CalorieTrackerExecutor calExecutor) {
    this.calExecutor=calExecutor;
  }


  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==menuOptionsCalendarSetYear) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Set Year Dialog", "Year:", "Set Year");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      if(strInput.length()!=4) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Year Dialog", "The year entered must be 4 digits long.");
        mDialog.show();

        return;
      }

      int intInput=-1;
      try {
        intInput=Integer.parseInt(strInput);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Year Dialog", "The year entered must be an integer.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarYear=intInput;

      calCanvas.repaint();
    }
    else if(evSource==menuOptionsCalendarSetMonth) {
      TextInputDialog tDialog=new TextInputDialog(this, "Calendar Set Month Dialog", "Month:", "Set Month");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strInput=tDialog.getInput();

      int intInput=-1;

      if(strInput.equals("January"))
        intInput=0;
      else if(strInput.equals("February"))
        intInput=1;
      else if(strInput.equals("March"))
        intInput=2;
      else if(strInput.equals("April"))
        intInput=3;
      else if(strInput.equals("May"))
        intInput=4;
      else if(strInput.equals("June"))
        intInput=5;
      else if(strInput.equals("July"))
        intInput=6;
      else if(strInput.equals("August"))
        intInput=7;
      else if(strInput.equals("September"))
        intInput=8;
      else if(strInput.equals("October"))
        intInput=9;
      else if(strInput.equals("November"))
        intInput=10;
      else if(strInput.equals("December"))
        intInput=11;
      else {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calendar Set Month Dialog", "The month entered was not recognized.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarMonth=intInput;

      calCanvas.repaint();
    }
  }

  class CalendarCanvas extends Canvas
  implements MouseListener {
    String strCalendarMonth[]={"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    String strWeekDays[]={"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

    int intDayWidth=-1;
    int intDayHeight=-1;

    int intCalendarYear=-1;
    int intCalendarMonth=-1;

    int intCharHeight=-1;

//    int intSelectedDay=1;

    CalendarCanvas() {
      super();

      addMouseListener(this);
    }

    public void initializeCanvas() {
      Date dateNow=new Date();
      intCalendarYear=dateNow.getYear()+1900;
      intCalendarMonth=dateNow.getMonth();
    }

    public void initializeCanvas2() {
      Dimension canvasDim=getSize();

      int intHeight=canvasDim.height;
      intHeight-=(intCharHeight*2+10);

      intDayWidth=canvasDim.width/7;
      intDayHeight=intHeight/6;
    }

    public void mouseEntered(MouseEvent me) {
    }

    public void mouseExited(MouseEvent me) {
    }

    public void mousePressed(MouseEvent me) {
    }

    public void mouseReleased(MouseEvent me) {
    }

    public void mouseClicked(MouseEvent me) {
      Point mePoint=me.getPoint();

      int meX=mePoint.x;
      int meY=mePoint.y;

      meY-=(intCharHeight*2+10);

      int intSelectedX=meX/intDayWidth;
      int intSelectedY=meY/intDayHeight;

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      int intDay=1;

      int intSelectedDay=-1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(intSelectedY==0 && i==intSelectedX) {
          intSelectedDay=intDay;
//          repaint();
          break;
        }

        ++intDay;
      }

      if(intSelectedDay==-1) {

        int intNextY=1;


        while(true) {
          for(int i=0;i<7;i++) {
            if(intSelectedY==intNextY && intSelectedX==i) {
              intSelectedDay=intDay;
//              repaint();
              break;
            }

            ++intDay;

            gCal.set(Calendar.DAY_OF_MONTH, intDay);

            if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
              return;
            }
          }

          if(intSelectedDay!=-1)
            break;

          ++intNextY;
        }      
      }

      if(intSelectedDay!=-1) {
        calExecutor.showAverageCalories(intCalendarYear, intCalendarMonth, intSelectedDay);

        calExecutor.setVisible(true);
        refThis.setVisible(false);
      }
    }

    public void paint(Graphics graph) {
      if(intCalendarMonth==-1)
        return;

      if(intCharHeight==-1) {
        FontMetrics fMetr=graph.getFontMetrics();
        intCharHeight=fMetr.getHeight();

        initializeCanvas2();
      }

      graph.drawString(String.valueOf(intCalendarYear)+" : "+strCalendarMonth[intCalendarMonth], 5, intCharHeight+5);

      int intXPosition=0;

      for(int i=0;i<7;i++) {
        graph.drawString(strWeekDays[i], intXPosition, intCharHeight+5+intCharHeight+5);

        intXPosition+=intDayWidth;
      }

      for(int i=0;i<=7;i++) {
        graph.drawLine(i*intDayWidth, intCharHeight*2+10, i*intDayWidth, getSize().height);
      }

      graph.drawLine(0, 0, getSize().width, 0);

      graph.drawLine(0, intCharHeight+5, getSize().width, intCharHeight+5);

      for(int i=0;i<=6;i++) {
        graph.drawLine(0, i*intDayHeight+intCharHeight*2+10, getSize().width, i*intDayHeight+intCharHeight*2+10);
      }

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      intXPosition=intDayOfWeek*intDayWidth;

      int intDay=1;

      for(int i=intDayOfWeek;i<7;i++) {
        graph.drawString(String.valueOf(intDay), intXPosition+5, intCharHeight+5+intCharHeight+5+intCharHeight+5);

        ++intDay;

        intXPosition+=intDayWidth;
      }

      int intYPosition=intCharHeight+5+intCharHeight+5;
      intYPosition+=intDayHeight;

      while(true) {
        intXPosition=0;

        boolean blnMustBreak=false;
        for(int i=0;i<7;i++) {
          graph.drawString(String.valueOf(intDay), intXPosition+5, intYPosition+intCharHeight+5);

          ++intDay;

          intXPosition+=intDayWidth;

          gCal.set(Calendar.DAY_OF_MONTH, intDay);

          if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
            blnMustBreak=true;
            break;
          }
        }

        if(blnMustBreak)
          break;

        intYPosition+=intDayHeight;
      }
    }
  }
}