package bim.calorieTracker;

import java.io.Serializable;
import java.util.Date;

class MealObject
implements Serializable {
  String strName;
  Integer intCalories;
  Date dateDate;

  MealObject(String strName, int intCalories, Date dateDate) {
    this.strName=strName;
    this.intCalories=new Integer(intCalories);
    this.dateDate=dateDate;
  }

  public String getName() {
    return strName;
  }

  public void setName(String strName) {
    this.strName=strName;
  }

  public int getCalories() {
    return intCalories.intValue();
  }

  public void setCalories(int intCalories) {
    this.intCalories=new Integer(intCalories);
  }

  public Date getDate() {
    return dateDate;
  }

  public void setDate(Date dateDate) {
    this.dateDate=dateDate;
  }
}