package bim.calorieTracker;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Hashtable;
import java.util.Map;
import java.util.Iterator;
import java.util.Vector;
import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;

class CalorieTrackerExecutor extends Frame
implements ActionListener {
  Dimension screenDim;
  CalendarCanvas calCanvas=new CalendarCanvas();

  CalendarObject calObj;

  Hashtable hashCalorieActivities=new Hashtable();

  int intWeight=-1;


  static int VIEW_AVERAGE_CALORIES_CHOICE_WEEK=0;
  static int VIEW_AVERAGE_CALORIES_CHOICE_MONTH=1;
  static int VIEW_AVERAGE_CALORIES_CHOICE_YEAR=2;

  int intViewAverageCaloriesChoice=-1;


  Menu menuFile=new Menu("File");
  MenuItem menuFileExit=new MenuItem("Exit");

  Menu menuOptions=new Menu("Options");
  MenuItem menuOptionsSetWeight=new MenuItem("Set Weight");
  MenuItem menuOptionsSetCalendar=new MenuItem("Set Calendar");
  MenuItem menuOptionsModifyMeals=new MenuItem("Modify Meals");
  MenuItem menuOptionsViewAverageCalories=new MenuItem("View Average Calories");
  MenuItem menuOptionsCalculateWorkout=new MenuItem("Calculate Workout");

  public static void main(String args[]) {
    try {
      CalorieTrackerExecutor cFrame=new CalorieTrackerExecutor();
      cFrame.screenDim=Toolkit.getDefaultToolkit().getScreenSize();
      cFrame.setSize(cFrame.screenDim.width, cFrame.screenDim.height-40);
      cFrame.setVisible(true);

      File fileWeight=new File("Weight");
      if(fileWeight.exists()) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileWeight));
        cFrame.intWeight=((Integer)ois.readObject()).intValue();
        ois.close();
      }

      File fileCalendar=new File("CalendarObject");
      if(fileCalendar.exists()) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileCalendar));
        cFrame.calObj=(CalendarObject)ois.readObject();
        ois.close();
      }
      else {
        cFrame.calObj=new CalendarObject();
      }

      File fileCalorieActivities=new File("CalorieActivities");
      if(fileCalorieActivities.exists()) {
        ObjectInputStream ois=new ObjectInputStream(new FileInputStream(fileCalorieActivities));
        cFrame.hashCalorieActivities=(Hashtable)ois.readObject();
        ois.close();
      }


      cFrame.calCanvas.initializeCanvas();
      cFrame.calCanvas.repaint();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  CalorieTrackerExecutor() {
    super("Calorie Tracker");

    setIconImage(new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent we) {
        System.exit(0);
      }
    });

    add("Center", calCanvas);

    menuFile.add(menuFileExit);
    menuFileExit.addActionListener(this);

    menuOptions.add(menuOptionsSetWeight);
    menuOptionsSetWeight.addActionListener(this);
    menuOptions.add(menuOptionsSetCalendar);
    menuOptionsSetCalendar.addActionListener(this);
    menuOptions.add(menuOptionsModifyMeals);
    menuOptionsModifyMeals.addActionListener(this);
    menuOptions.add(menuOptionsViewAverageCalories);
    menuOptionsViewAverageCalories.addActionListener(this);
    menuOptions.add(menuOptionsCalculateWorkout);
    menuOptionsCalculateWorkout.addActionListener(this);

    MenuBar mBar=new MenuBar();

    mBar.add(menuFile);
    mBar.add(menuOptions);

    setMenuBar(mBar);
  }

  public void incrementDay(GregorianCalendar gCal) {
    gCal.add(Calendar.DAY_OF_MONTH, 1);

/*
    gCal.set(Calendar.DAY_OF_MONTH, intDay);

    if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
      blnMustBreak=true;
      break;
    }
*/
  }

  public void showAverageCalories(int intCalendarYear, int intCalendarMonth, int intSelectedDay) {
    Hashtable hashMeals=calObj.getMeals();

//    int intAverageCalories=0;

//    int intIncludedDaysCount=0;

    GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, intSelectedDay);

    int intCalendarYearStart=intCalendarYear;
    int intCalendarMonthStart=intCalendarMonth;

    int intDay=intSelectedDay;

    int intDaysOfWeek[]=new int[7];
    for(int i=0;i<intDaysOfWeek.length;i++)
      intDaysOfWeek[i]=0;
    int intDaysOfWeekIncluded[]=new int[7];
    for(int i=0;i<intDaysOfWeekIncluded.length;i++)
      intDaysOfWeekIncluded[i]=0;
//    int intDaysOfWeekNotIncluded[]=new int[7];
//    for(int i=0;i<intDaysOfWeekNotIncluded.length;i++)
//      intDaysOfWeekNotIncluded[i]=0;
    int intDaysOfWeekIncludedLastCalories[]=new int[7];
    for(int i=0;i<intDaysOfWeekIncludedLastCalories.length;i++)
      intDaysOfWeekIncludedLastCalories[i]=-1;

    String strDuration="";

    if(intViewAverageCaloriesChoice==VIEW_AVERAGE_CALORIES_CHOICE_WEEK) {
      strDuration="Week";

      for(int i=0;i<7;i++) {
        Vector vecMeals=(Vector)hashMeals.get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));

        if(vecMeals!=null) {
          int intCalorieCount=0;

          for(int ia=0;ia<vecMeals.size();ia++) {
            MealObject nextMeal=(MealObject)vecMeals.elementAt(ia);
            intCalorieCount+=nextMeal.getCalories();
          }

          if(intCalorieCount>0) {
            intDaysOfWeek[gCal.get(Calendar.DAY_OF_WEEK)-1]+=intCalorieCount;
            intDaysOfWeekIncludedLastCalories[gCal.get(Calendar.DAY_OF_WEEK)-1]=intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1];

//            intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1]+=1;
          }
//          else {
//            intDaysOfWeekNotIncluded[gCal.get(Calendar.DAY_OF_WEEK)]+=1;
//          }
        }
//        else {
//          intDaysOfWeekNotIncluded[gCal.get(Calendar.DAY_OF_WEEK)]+=1;
//        }

        intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1]+=1;

        incrementDay(gCal);

        intCalendarYear=gCal.get(Calendar.YEAR);
        intCalendarMonth=gCal.get(Calendar.MONTH);
        intDay=gCal.get(Calendar.DATE);
      }
    }
    else if(intViewAverageCaloriesChoice==VIEW_AVERAGE_CALORIES_CHOICE_MONTH) {
      strDuration="Month";

      for(int i=0;i<30;i++) {
        Vector vecMeals=(Vector)hashMeals.get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));

        if(vecMeals!=null) {
          int intCalorieCount=0;

          for(int ia=0;ia<vecMeals.size();ia++) {
            MealObject nextMeal=(MealObject)vecMeals.elementAt(ia);
            intCalorieCount+=nextMeal.getCalories();
          }

          if(intCalorieCount>0) {
            intDaysOfWeek[gCal.get(Calendar.DAY_OF_WEEK)-1]+=intCalorieCount;
            intDaysOfWeekIncludedLastCalories[gCal.get(Calendar.DAY_OF_WEEK)-1]=intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1];

//            intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1]+=1;
          }
//          else {
//            intDaysOfWeekNotIncluded[gCal.get(Calendar.DAY_OF_WEEK)]+=1;
//          }
        }
//        else {
//          intDaysOfWeekNotIncluded[gCal.get(Calendar.DAY_OF_WEEK)]+=1;
//        }

        intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1]+=1;

        incrementDay(gCal);

        intCalendarYear=gCal.get(Calendar.YEAR);
        intCalendarMonth=gCal.get(Calendar.MONTH);
        intDay=gCal.get(Calendar.DATE);
      }
    }
    else if(intViewAverageCaloriesChoice==VIEW_AVERAGE_CALORIES_CHOICE_YEAR) {
      strDuration="Year";

      for(int i=0;i<365;i++) {
        Vector vecMeals=(Vector)hashMeals.get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));

        if(vecMeals!=null) {
          int intCalorieCount=0;

          for(int ia=0;ia<vecMeals.size();ia++) {
            MealObject nextMeal=(MealObject)vecMeals.elementAt(ia);
            intCalorieCount+=nextMeal.getCalories();
          }

          if(intCalorieCount>0) {
            intDaysOfWeek[gCal.get(Calendar.DAY_OF_WEEK)-1]+=intCalorieCount;
            intDaysOfWeekIncludedLastCalories[gCal.get(Calendar.DAY_OF_WEEK)-1]=intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1];

//            intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1]+=1;
          }
//          else {
//            intDaysOfWeekNotIncluded[gCal.get(Calendar.DAY_OF_WEEK)]+=1;
//          }
        }
//        else {
//          intDaysOfWeekNotIncluded[gCal.get(Calendar.DAY_OF_WEEK)]+=1;
//        }

        intDaysOfWeekIncluded[gCal.get(Calendar.DAY_OF_WEEK)-1]+=1;

        incrementDay(gCal);

        intCalendarYear=gCal.get(Calendar.YEAR);
        intCalendarMonth=gCal.get(Calendar.MONTH);
        intDay=gCal.get(Calendar.DATE);
      }
    }

//    double dblDaysOfWeekIncludedAll=0.0d;

    int intAverageCalories[]=new int[7];
    for(int i=0;i<intAverageCalories.length;i++) {
      if(intDaysOfWeek[i]==0 || intDaysOfWeekIncluded[i]==0) {
        intAverageCalories[i]=0;
      }
      else {
        intDaysOfWeekIncluded[i]=intDaysOfWeekIncludedLastCalories[i]+1;

        intAverageCalories[i]=intDaysOfWeek[i]/intDaysOfWeekIncluded[i];
//        dblDaysOfWeekIncludedAll+=((double)intDaysOfWeekIncluded[i]);
      }
    }

/*
    if(dblDaysOfWeekIncludedAll==0.0d)
      return;

    double dblAverageCaloriesAll=0.0d;
    for(int i=0;i<intAverageCalories.length;i++) {
      dblAverageCaloriesAll=dblAverageCaloriesAll+((double)intAverageCalories[i])*((double)intDaysOfWeekIncluded[i])/dblDaysOfWeekIncludedAll;
    }

    int intAverageCaloriesAll=(int)Math.rint(dblAverageCaloriesAll);

    for(int i=0;i<intAverageCalories.length;i++) {
      if(intAverageCalories[i]==0)
        intAverageCalories[i]=intAverageCaloriesAll;
    }
*/

    ViewAverageCaloriesComputedDialog vDialog=new ViewAverageCaloriesComputedDialog(this, new Date(intCalendarYearStart-1900, intCalendarMonthStart, intSelectedDay), strDuration, intAverageCalories);
    vDialog.show();
  }

  public void actionPerformed(ActionEvent ae) {
    Object evSource=ae.getSource();

    if(evSource==menuFileExit) {
      System.exit(0);
    }
    else if(evSource==menuOptionsSetWeight) {
      TextInputDialog tDialog=new TextInputDialog(this, "Set Weight Dialog", "Weight:", "Set Weight");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strWeight=tDialog.getInput();

      int intWeight0=-1;
      try {
        intWeight0=Integer.parseInt(strWeight);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Weight Dialog", "Weight must be an integer from 80-500.");
        mDialog.show();

        return;
      }

      if(intWeight0<80 || intWeight0>500) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Weight Dialog", "Weight must be an integer from 80-500.");
        mDialog.show();

        return;
      }

      intWeight0=intWeight0-(intWeight0%10);

      intWeight=intWeight0;

      try {
        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("Weight")));
        oos.writeObject(new Integer(intWeight));
        oos.close();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==menuOptionsSetCalendar) {
      TextInputDialog tDialog=new TextInputDialog(this, "Set Calendar Dialog: Year", "Year:", "Set Year");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strYear=tDialog.getInput();

      int intYear=-1;
      try {
        intYear=Integer.parseInt(strYear);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Calendar Dialog: Year", "Year must be an integer.");
        mDialog.show();

        return;
      }


      tDialog=new TextInputDialog(this, "Set Calendar Dialog: Month", "Month:", "Set Month");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strMonth=tDialog.getInput();

      int intMonth=-1;

      if(strMonth.equals("January"))
        intMonth=0;
      else if(strMonth.equals("February"))
        intMonth=1;
      else if(strMonth.equals("March"))
        intMonth=2;
      else if(strMonth.equals("April"))
        intMonth=3;
      else if(strMonth.equals("May"))
        intMonth=4;
      else if(strMonth.equals("June"))
        intMonth=5;
      else if(strMonth.equals("July"))
        intMonth=6;
      else if(strMonth.equals("August"))
        intMonth=7;
      else if(strMonth.equals("September"))
        intMonth=8;
      else if(strMonth.equals("October"))
        intMonth=9;
      else if(strMonth.equals("November"))
        intMonth=10;
      else if(strMonth.equals("December"))
        intMonth=11;
      else {
        MessageDialog mDialog=new MessageDialog(this, "Error. Set Calendar Dialog: Month", "Month \""+strMonth+"\" not found.");
        mDialog.show();

        return;
      }

      calCanvas.intCalendarYear=intYear;
      calCanvas.intCalendarMonth=intMonth;

      calCanvas.repaint();      
    }
    else if(evSource==menuOptionsModifyMeals) {
      if(calCanvas.intSelectedDay==-1)
        return;

      Date dateDate=new Date(calCanvas.intCalendarYear-1900, calCanvas.intCalendarMonth, calCanvas.intSelectedDay);

      Vector vecMeals=(Vector)calObj.getMeals().get(dateDate);

      if(vecMeals==null) {
        vecMeals=new Vector();
        calObj.getMeals().put(dateDate, vecMeals);
      }

      ModifyMealsDialog mDialog=new ModifyMealsDialog(this, dateDate, vecMeals);
      mDialog.show();

      try {
        ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(new File("CalendarObject")));
        oos.writeObject(calObj);
        oos.close();
      }
      catch(Exception ex) {
        ex.printStackTrace();
      }
    }
    else if(evSource==menuOptionsViewAverageCalories) {
      ViewAverageCaloriesChooserDurationDialog vDialog=new ViewAverageCaloriesChooserDurationDialog(this);
      vDialog.show();

      if(vDialog.cancelIt)
        return;

      intViewAverageCaloriesChoice=vDialog.getChoice();

      ViewAverageCaloriesChooserStartFrame vFrame=new ViewAverageCaloriesChooserStartFrame(this);
      vFrame.setSize(screenDim.width, screenDim.height);
      vFrame.setVisible(true);

      vFrame.calCanvas.initializeCanvas();
      vFrame.calCanvas.repaint();

      setVisible(false);
    }
    else if(evSource==menuOptionsCalculateWorkout) {
      if(intWeight==-1) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calculate Workout Dialog", "You must select a weight first.");
        mDialog.show();

        return;
      }

      TextInputDialog tDialog=new TextInputDialog(this, "Calculate Workout Dialog", "Calories to burn: ", "Set Calories to Burn");
      tDialog.show();

      if(tDialog.cancelIt)
        return;

      String strCaloriesToBurn=tDialog.getInput();

      if(strCaloriesToBurn.length()==0)
        return;

      int intCaloriesToBurn=-1;
      try {
        intCaloriesToBurn=Integer.parseInt(strCaloriesToBurn);
      }
      catch(Exception ex) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calculate Workout Dialog", "Calories to burn must be an integer.");
        mDialog.show();

        return;
      }

      if(intCaloriesToBurn<1) {
        MessageDialog mDialog=new MessageDialog(this, "Error. Calculate Workout Dialog", "Calories to burn must be a positve integer.");
        mDialog.show();

        return;
      }

      String strActivities[]=new String[hashCalorieActivities.size()];
      int intCount=0;
      Iterator iterator0=hashCalorieActivities.entrySet().iterator();
      while(iterator0.hasNext()) {
        Map.Entry mEntry=(Map.Entry)iterator0.next();
        String strActivity=(String)mEntry.getKey();
//        Hashtable hashWeight=(Hashtable)mEntry.getValue();
//        String strCalories=(String)hashWeight.get(String.valueOf(intWeight));
//        strActivity+=" : "+strCalories;
        strActivities[intCount++]=strActivity;
      }

      Arrays.sort(strActivities);

      List lstList=new List(5);
      for(int i=0;i<strActivities.length;i++)
        lstList.add(strActivities[i]);

      ListDialog2 lDialog=new ListDialog2(this, "Calculate Workout Dialog: Activity Selector", lstList);
      lDialog.show();

      if(lDialog.cancelIt)
        return;

      String strSelectedActivities[]=lstList.getSelectedItems();
      double dblPercentages[]=new double[strSelectedActivities.length];

      for(int i=0;i<strSelectedActivities.length;i++) {
        tDialog=new TextInputDialog(this, "Calculate Workout Dialog: "+strSelectedActivities[i], "Percentage of calories to burn(0-100): ", "Enter Percentage");
        tDialog.show();

        if(tDialog.cancelIt)
          return;

        try {
          dblPercentages[i]=Double.valueOf(tDialog.getInput());
        }
        catch(Exception ex) {
          MessageDialog mDialog=new MessageDialog(this, "Error. Calculate Workout Dialog", "Percentage entered must be from 0-100.");
          mDialog.show();

          continue;
        }

        dblPercentages[i]/=100.0d;
      }

      double dblCaloriesToBurn=(double)intCaloriesToBurn;

      String strWorkout="";

      for(int i=0;i<strSelectedActivities.length;i++) {
        strWorkout+=strSelectedActivities[i]+" workout for ";

        double dblCaloriesToBurnSingle=dblCaloriesToBurn*dblPercentages[i];

        String strCalories=(String)((Hashtable)hashCalorieActivities.get(strSelectedActivities[i])).get(String.valueOf(intWeight));
        double dblCalories=Double.valueOf(strCalories).doubleValue();

        double dblHours=dblCaloriesToBurnSingle/dblCalories;

        double dblMinutes=dblHours*60.0d;

        dblMinutes=Math.ceil(dblMinutes);

        strWorkout+=((int)dblMinutes);

        strWorkout+=" minutes\n";
      }

      MessageDialog2 mDialog=new MessageDialog2(this, "Computed Workout Details Dialog", strWorkout);
      mDialog.show();
    }
  }

  class CalendarCanvas extends Canvas
  implements MouseListener {
    String strCalendarMonth[]={"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    String strWeekDays[]={"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

    int intDayWidth=-1;
    int intDayHeight=-1;

    int intCalendarYear=-1;
    int intCalendarMonth=-1;

    int intCharHeight=-1;

    int intSelectedDay=1;

    CalendarCanvas() {
      super();

      addMouseListener(this);
    }

    public void initializeCanvas() {
      Date dateNow=new Date();
      intCalendarYear=dateNow.getYear()+1900;
      intCalendarMonth=dateNow.getMonth();
    }

    public void initializeCanvas2() {
      Dimension canvasDim=getSize();

      int intHeight=canvasDim.height;
      intHeight-=(intCharHeight*2+10);

      intDayWidth=canvasDim.width/7;
      intDayHeight=intHeight/6;
    }

    public void mouseEntered(MouseEvent me) {
    }

    public void mouseExited(MouseEvent me) {
    }

    public void mousePressed(MouseEvent me) {
    }

    public void mouseReleased(MouseEvent me) {
    }

    public void mouseClicked(MouseEvent me) {
      Point mePoint=me.getPoint();

      int meX=mePoint.x;
      int meY=mePoint.y;

      meY-=(intCharHeight*2+10);

      int intSelectedX=meX/intDayWidth;
      int intSelectedY=meY/intDayHeight;

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      int intDay=1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(intSelectedY==0 && i==intSelectedX) {
          intSelectedDay=intDay;
          repaint();
          return;
        }

        ++intDay;
      }

      int intNextY=1;


      while(true) {
        for(int i=0;i<7;i++) {
          if(intSelectedY==intNextY && intSelectedX==i) {
            intSelectedDay=intDay;
            repaint();
            return;
          }

          ++intDay;

          gCal.set(Calendar.DAY_OF_MONTH, intDay);

          if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
            return;
          }
        }

        ++intNextY;
      }      
    }

    public void paint(Graphics graph) {
      if(intCalendarMonth==-1)
        return;

      if(intCharHeight==-1) {
        FontMetrics fMetr=graph.getFontMetrics();
        intCharHeight=fMetr.getHeight();

        initializeCanvas2();
      }

      graph.drawString(String.valueOf(intCalendarYear)+" : "+strCalendarMonth[intCalendarMonth], 5, intCharHeight+5);

      int intXPosition=0;

      for(int i=0;i<7;i++) {
        graph.drawString(strWeekDays[i], intXPosition, intCharHeight+5+intCharHeight+5);

        intXPosition+=intDayWidth;
      }

      for(int i=0;i<=7;i++) {
        graph.drawLine(i*intDayWidth, intCharHeight*2+10, i*intDayWidth, getSize().height);
      }

      graph.drawLine(0, 0, getSize().width, 0);

      graph.drawLine(0, intCharHeight+5, getSize().width, intCharHeight+5);

      for(int i=0;i<=6;i++) {
        graph.drawLine(0, i*intDayHeight+intCharHeight*2+10, getSize().width, i*intDayHeight+intCharHeight*2+10);
      }

      GregorianCalendar gCal=new GregorianCalendar(intCalendarYear, intCalendarMonth, 1);

      int intDayOfWeek=gCal.get(Calendar.DAY_OF_WEEK);
      --intDayOfWeek;
//0 is sunday and 6 is saturday

      intXPosition=intDayOfWeek*intDayWidth;

      int intDay=1;

      for(int i=intDayOfWeek;i<7;i++) {
        if(intSelectedDay==intDay) {
          graph.setColor(Color.green);
          graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
          graph.setColor(Color.black);
        }
        else {
          Vector vecAppointments=(Vector)calObj.getMeals().get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));
          if(vecAppointments!=null) {
            if(vecAppointments.size()>0) {
              graph.setColor(Color.red);
              graph.fillRect(intXPosition, intCharHeight*2+10, intDayWidth, intDayHeight);
              graph.setColor(Color.black);
            }
          }
        }

        graph.drawString(String.valueOf(intDay), intXPosition+5, intCharHeight+5+intCharHeight+5+intCharHeight+5);

        ++intDay;

        intXPosition+=intDayWidth;
      }

      int intYPosition=intCharHeight+5+intCharHeight+5;
      intYPosition+=intDayHeight;

      while(true) {
        intXPosition=0;

        boolean blnMustBreak=false;
        for(int i=0;i<7;i++) {
          if(intSelectedDay==intDay) {
            graph.setColor(Color.green);
            graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
            graph.setColor(Color.black);
          }
          else {
            Vector vecAppointments=(Vector)calObj.getMeals().get(new Date(intCalendarYear-1900, intCalendarMonth, intDay));
            if(vecAppointments!=null) {
              if(vecAppointments.size()>0) {
                graph.setColor(Color.red);
                graph.fillRect(intXPosition, intYPosition, intDayWidth, intDayHeight);
                graph.setColor(Color.black);
              }
            }
          }

          graph.drawString(String.valueOf(intDay), intXPosition+5, intYPosition+intCharHeight+5);

          ++intDay;

          intXPosition+=intDayWidth;

          gCal.set(Calendar.DAY_OF_MONTH, intDay);

          if(gCal.get(Calendar.DAY_OF_MONTH)==1) {
            blnMustBreak=true;
            break;
          }
        }

        if(blnMustBreak)
          break;

        intYPosition+=intDayHeight;
      }
    }
  }

  class ViewAverageCaloriesChooserDurationDialog extends Dialog
  implements ActionListener {
    CheckboxGroup cbg=new CheckboxGroup();
    Checkbox cbWeek=new Checkbox("Week", cbg, true);
    Checkbox cbMonth=new Checkbox("Month", cbg, false);
    Checkbox cbYear=new Checkbox("Year", cbg, false);
    volatile int intChoice=-1;

    Button btnSelectDuration=new Button("Select Duration");
    Button btnCancel=new Button("Cancel");
    volatile boolean cancelIt=false;


    ViewAverageCaloriesChooserDurationDialog(Frame parent) {
      super(parent, "View Average Calories Chooser Duration Dialog", true);

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(2, 1));
      tempPan.add(new Label("Duration:"));
      Panel tempPanA=new Panel();
      tempPanA.setLayout(new GridLayout(1, 3));
      tempPanA.add(cbWeek);
      tempPanA.add(cbMonth);
      tempPanA.add(cbYear);
      tempPan.add(tempPanA);

      add("North", tempPan);

      add("Center", new Label(""));

      Panel tempPan2=new Panel();
      tempPan2.add(btnSelectDuration);
      btnSelectDuration.addActionListener(this);
      tempPan2.add(btnCancel);
      btnCancel.addActionListener(this);

      add("South", tempPan2);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public int getChoice() {
      return intChoice;
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnSelectDuration) {
        if(cbWeek.getState())
          intChoice=VIEW_AVERAGE_CALORIES_CHOICE_WEEK;
        else if(cbMonth.getState())
          intChoice=VIEW_AVERAGE_CALORIES_CHOICE_MONTH;
        else if(cbYear.getState())
          intChoice=VIEW_AVERAGE_CALORIES_CHOICE_YEAR;

        cancelIt=false;
        dispose();
      }
      else if(evSource==btnCancel) {
        cancelIt=true;
        dispose();
      }
    }
  }

  class ViewAverageCaloriesComputedDialog extends Dialog
  implements ActionListener {
    Button btnClose=new Button("Close");

    ViewAverageCaloriesComputedDialog(Frame parent, Date dateStart, String strDuration, int intAverageCalories[]) {
      super(parent, dateStart.toString()+" to "+strDuration, true);

      Panel tempPan=new Panel();
      tempPan.setLayout(new GridLayout(7, 2));
      tempPan.add(new Label("Sunday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[0])));
      tempPan.add(new Label("Monday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[1])));
      tempPan.add(new Label("Tuesday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[2])));
      tempPan.add(new Label("Wednesday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[3])));
      tempPan.add(new Label("Thursday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[4])));
      tempPan.add(new Label("Friday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[5])));
      tempPan.add(new Label("Saturday: "));
      tempPan.add(new Label(String.valueOf(intAverageCalories[6])));

      add("North", tempPan);

      add("Center", new Label(""));

      Panel tempPan2=new Panel();
      tempPan2.add(btnClose);
      btnClose.addActionListener(this);

      add("South", tempPan2);

      setLocation(screenDim.width/4, screenDim.height/4);
      setSize(screenDim.width/2, screenDim.height/2);
    }

    public void actionPerformed(ActionEvent ae) {
      Object evSource=ae.getSource();

      if(evSource==btnClose) {
        dispose();
      }
    }
  }
}